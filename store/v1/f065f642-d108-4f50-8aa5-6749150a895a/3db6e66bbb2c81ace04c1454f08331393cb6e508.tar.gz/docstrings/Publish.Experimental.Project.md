<div class='docs' id='Project'>

`public` `Project` — `struct`

<div class='doc' id='1'>

    Project(pages...; config...)

Virtual Publish project object for programmatically building a document.
`pages` can be any number of `Page` objects. `config` is any number of keyword
arguments which is used to build the generated project’s `Project.toml`.

</div>

</div>
