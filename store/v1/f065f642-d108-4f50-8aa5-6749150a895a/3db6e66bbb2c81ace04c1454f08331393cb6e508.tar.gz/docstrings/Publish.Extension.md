<div class='docs' id='Extension'>

`private` `Extension` — `parametric type`

<div class='doc' id='1'>

A dispatch type used to make file loading extensible by extension name.

</div>

</div>
