<div class='docs' id='display_as'>

`private` `display_as` — `function`

<div class='doc' id='1'>

    display_as(default, cell, writer, [mimes...])

Given a `cell` this function evaluates it and prints the output to `writer`
using the first available `MIME` from `mimes`. Uses the `default` printer
function to print any code blocks that are required in the output.

</div>

</div>
