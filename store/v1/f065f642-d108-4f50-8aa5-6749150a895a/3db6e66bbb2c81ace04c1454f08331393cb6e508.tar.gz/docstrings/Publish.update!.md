<div class='docs' id='update!'>

`private` `update!` — `function`

<div class='doc' id='1'>

    update!(project)

Reload contents of the given `project`.

</div>

</div>
