<div class='docs' id='rmerge'>

`private` `rmerge` — `function`

<div class='doc' id='1'>

    rmerge(ds...)

Recursively merge the `Dict`s provided in `ds`. Last argument wins when
conflicts occur.

</div>

</div>
