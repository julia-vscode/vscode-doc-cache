<div class='docs' id='loaddocs'>

`private` `loaddocs` — `function`

<div class='doc' id='1'>

Loads “virtual” files for each docstring that is defined within the given
project. Merges these files into the given `tree` as well as appending them to
`pages`.

</div>

</div>
