<div class='docs' id='relative_paths'>

`private` `relative_paths` — `function`

<div class='doc' id='1'>

    relative_paths(func, project, file)

Rewrite any file paths within a [`Project`](Publish.Project.md)’s `.env` to be relative to the
given `file` and pass then to the `func` argument for evaluation.

</div>

</div>
