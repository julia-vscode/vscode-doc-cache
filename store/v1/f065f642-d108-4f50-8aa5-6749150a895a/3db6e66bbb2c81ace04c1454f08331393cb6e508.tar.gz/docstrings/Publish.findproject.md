<div class='docs' id='findproject'>

`private` `findproject` — `function`

<div class='doc' id='1'>

    findproject(mod)

Returns the path to the configuration file for the module `mod`.

When no path can be found, for example `Base` and it’s modules, then `nothing`
is returned instead.

</div>

</div>
