<div class='docs' id='init'>

`private` `init` — `function`

<div class='doc' id='1'>

Function for defining the initialisation code called by [`serve`](Publish.serve.md)
for a specific target output.

Should be defined for each valid output target, i.e [`html`](Publish.html.md), [`pdf`](Publish.pdf.md),
etc. Signature should follow the following template:

```julia
function init(project::Project, ::typeof(target); kws...)
    # ...
end
```

where `target` is the `Function` defining the output format.

</div>

</div>
