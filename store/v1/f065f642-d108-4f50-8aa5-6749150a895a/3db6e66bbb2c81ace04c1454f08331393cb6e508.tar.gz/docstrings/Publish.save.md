<div class='docs' id='save'>

`private` `save` — `function`

<div class='doc' id='1'>

    save(f, tree)

Wrapper function for `FileTrees.save` to configure whether to use parallel
saving using `FileTrees` or to just use a basic serial implementation.
Typically the simpler serial code will be faster unless the project is very
large.

</div>

</div>
