<div class='docs' id='loadpages'>

`private` `loadpages` — `function`

<div class='doc' id='1'>

    loadpages(tree, env)

Finds all files defined by the project’s table of contents and loads them into
the `tree`.

</div>

</div>
