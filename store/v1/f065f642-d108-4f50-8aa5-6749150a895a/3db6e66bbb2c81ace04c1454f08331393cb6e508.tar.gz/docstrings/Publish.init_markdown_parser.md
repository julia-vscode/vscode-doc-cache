<div class='docs' id='init_markdown_parser'>

`private` `init_markdown_parser` — `function`

<div class='doc' id='1'>

    init_markdown_parser()

Returns a new `CommonMark.Parser` object with all extensions enabled.

</div>

</div>
