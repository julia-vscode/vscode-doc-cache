<div class='docs' id='loadtheme'>

`private` `loadtheme` — `function`

<div class='doc' id='1'>

    loadtheme(tree, env)

Searches the given `env` configuration for a Publish.jl theme and loads it into
the provided `tree`. Since `tree` is immutable the updated version is returned
along with a new `env` containing any merged data from the theme.

`loadtheme` looks for a `publish.theme` key in the `env` and tries to call the
function defined by the value of the key.

The themes included with this package are listed in the [`Themes`](Publish.Themes.md) module.

</div>

</div>
