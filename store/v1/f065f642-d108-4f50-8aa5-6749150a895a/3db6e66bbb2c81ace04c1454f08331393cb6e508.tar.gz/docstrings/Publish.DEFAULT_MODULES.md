<div class='docs' id='DEFAULT_MODULES'>

`private` `DEFAULT_MODULES` — `constant`

<div class='doc' id='1'>

The set of modules available to all packages.

</div>

</div>
