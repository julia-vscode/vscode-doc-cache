<div class='docs' id='Themes'>

`private` `Themes` — `module`

<div class='doc' id='1'>

Namespace for all themes that are provided with the package.

Themes defined here should be 0-arity functions that return the absolute path
to the folder containing the theme definition.

Provided themes are currently:

  - [`default`](Publish.Themes.default.md "`Themes.default`")

</div>

</div>
