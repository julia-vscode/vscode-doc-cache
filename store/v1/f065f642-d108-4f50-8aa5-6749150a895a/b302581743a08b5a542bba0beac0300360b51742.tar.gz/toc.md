{style="text-align: center"}
**MANUAL**

{style="margin: 0 auto; max-width: 350px"}
 1. [Introduction](README.md)
 2. [Getting Started](docs/getting_started.md)
 3. [Project Structure](docs/structure.md)
 4. [Cross Referencing](docs/references.md)
 5. [Configuration](docs/config.md)
 6. [Templates](docs/templates.md)
 7. [Custom Themes](docs/themes.md)
 8. [Source Types](docs/sources.md)
 9. [Executable “Cells”](docs/cells.md)
10. [Markdown Syntax](docs/syntax.md)

{style="text-align: center"}
**Examples**

{style="list-style: none; margin: 0 auto; max-width: 350px"}
  - [Basics](examples/basics.md)
  - [Cells](examples/cells.md)

{style="text-align: center"}
[**LIBRARY INDEX**](docstrings.md)

{style="text-align: center"}
**SOURCE**

{style="margin: 0 auto; max-width: 350px"}
  - [`Publish.jl`](src/Publish.md)
  - [`projects.jl`](src/projects.md)
  - [`themes.jl`](src/themes.md)
  - [`load.jl`](src/load.md)
  - [`cells.jl`](src/cells.md)
  - [`save.jl`](src/save.md)
  - [`serve.jl`](src/serve.md)
  - [`deploy.jl`](src/deploy.md)
  - [`tools.jl`](src/tools.md)
  - [`utilities.jl`](src/utilities.md)

{style="text-align: center"}
[**LICENSE**](LICENSE.md)
