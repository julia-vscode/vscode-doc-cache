<div class='docs' id='Project'>

`private` `Project` — `struct`

<div class='doc' id='1'>

    struct Project

A `struct` that holds details of a “project”, which is defined as

> a configuration file (in TOML format), along with a collection of associated
> source and support files.

“Projects” can be created in two ways, by `Module`, or configuration path.

</div>

<div class='doc' id='2'>

    Project(mod)

Create a new [`Project`](Publish.Project.md) object from the given module `mod`.

</div>

<div class='doc' id='3'>

    Project(path)

Create a new [`Project`](Publish.Project.md) object from the given configuration `path`. The
`path` must be a TOML file.

</div>

</div>
