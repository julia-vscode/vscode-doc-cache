<div class='docs' id='json_search_data'>

`private` `json_search_data` — `function`

<div class='doc' id='1'>

Extract JSON search data from a project for use in lunr.js.

</div>

</div>
