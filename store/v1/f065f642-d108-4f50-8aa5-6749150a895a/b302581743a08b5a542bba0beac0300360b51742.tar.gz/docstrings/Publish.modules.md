<div class='docs' id='modules'>

`private` `modules` — `function`

<div class='doc' id='1'>

    modules(root)

Returns the set of modules visible from the given `root` module.

</div>

</div>
