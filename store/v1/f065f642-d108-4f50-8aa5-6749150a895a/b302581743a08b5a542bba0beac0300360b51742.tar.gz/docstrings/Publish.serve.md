<div class='docs' id='serve'>

`public` `serve` — `function`

<div class='doc' id='1'>

Start a server to present built output of project `src` for the given
`targets`. The actions performed by each `target` are defined by the targets
themselves. The default target used is [`html`](Publish.html.md).

</div>

</div>
