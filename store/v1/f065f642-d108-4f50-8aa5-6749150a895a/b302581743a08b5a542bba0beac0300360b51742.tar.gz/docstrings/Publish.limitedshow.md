<div class='docs' id='limitedshow'>

`private` `limitedshow` — `function`

<div class='doc' id='1'>

    limitedshow([io], mime, result)

Prints out a “limited” representation of `result` in the given `mime` to the
provided `io` stream, or returns a `String` of the output when no `io` is
given.

</div>

</div>
