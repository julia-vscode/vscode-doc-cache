<div class='docs' id='revise'>

`private` `revise` — `function`

<div class='doc' id='1'>

    revise(project)

When Revise.jl is loaded in the current session trigger `Revise.revise`.

</div>

</div>
