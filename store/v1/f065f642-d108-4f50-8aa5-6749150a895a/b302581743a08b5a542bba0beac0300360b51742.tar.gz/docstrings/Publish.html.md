<div class='docs' id='html'>

`public` `html` — `function`

<div class='doc' id='1'>

Convert the given `src` project to a collection of HTML files.

</div>

</div>
