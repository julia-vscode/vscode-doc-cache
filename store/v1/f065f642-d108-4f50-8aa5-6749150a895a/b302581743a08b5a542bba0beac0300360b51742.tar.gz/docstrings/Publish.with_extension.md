<div class='docs' id='with_extension'>

`private` `with_extension` — `function`

<div class='doc' id='1'>

    with_extension(path, ext)

Return a path with the extension set to `ext`.

</div>

</div>
