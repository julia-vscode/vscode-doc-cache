<div class='docs' id='categorise'>

`private` `categorise` — `function`

<div class='doc' id='1'>

    categorise(binding)

Returns the category of a given `Docs.Binding` object `binding`. These
categories are used for displaying details about docstrings.

</div>

</div>
