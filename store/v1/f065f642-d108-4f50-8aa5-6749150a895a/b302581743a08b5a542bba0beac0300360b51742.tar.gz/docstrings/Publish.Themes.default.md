<div class='docs' id='default'>

`private` `default` — `constant`

<div class='doc' id='1'>

The “default” theme used by this package.

</div>

</div>
