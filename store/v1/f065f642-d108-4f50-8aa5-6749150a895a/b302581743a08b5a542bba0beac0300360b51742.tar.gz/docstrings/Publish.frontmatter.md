<div class='docs' id='frontmatter'>

`private` `frontmatter` — `function`

<div class='doc' id='1'>

    frontmatter(ast)

Returns a `Dict` containing the front matter content of a markdown `ast`. When
no front matter is found then an empty `Dict` is returned.

</div>

</div>
