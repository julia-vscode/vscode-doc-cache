<div class='docs' id='watch_files!'>

`private` `watch_files!` — `function`

<div class='doc' id='1'>

Set files to watch for changes within a given [`Project`](Publish.Project.md) `p`.

</div>

</div>
