<div class='docs' id='loadfile'>

`private` `loadfile` — `function`

<div class='doc' id='1'>

    loadfile(env, path)

Loads a file. Extended by `loadfile` methods that dispatch based on the
[extension](Publish.Extension.md "`Extension`") of the file.

</div>

</div>
