<div class='docs' id='Page'>

`public` `Page` — `struct`

<div class='doc' id='1'>

    Page(blocks...)

Virtual page contents in a markdown file. Each block can be either a `String`,
which is interpreted as markdown text and directly embedded in the page, or any
other value, which will be embedded in a `{cell}` block.

</div>

</div>
