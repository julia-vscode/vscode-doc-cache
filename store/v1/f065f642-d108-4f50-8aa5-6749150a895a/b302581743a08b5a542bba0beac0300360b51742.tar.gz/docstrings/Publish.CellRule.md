<div class='docs' id='CellRule'>

`private` `CellRule` — `struct`

<div class='doc' id='1'>

A CommonMark rule used to define the “cell” parser. A `CellRule` holds a
`.cache` of the `Module`s that have been defined in a markdown document so that
cells can depend on definitions and values from previous cells.

</div>

</div>
