<div class='docs' id='binding'>

`private` `binding` — `function`

<div class='doc' id='1'>

Returns the `Docs.Binding` object given an expression or string.

</div>

</div>
