<div class='docs' id='sandbox'>

`private` `sandbox` — `function`

<div class='doc' id='1'>

    sandbox(f, path)

Evaluate the function `f` in the given folder given by `path`. When `path`
does not exist it is created first.

</div>

</div>
