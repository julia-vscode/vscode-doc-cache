<div class='docs' id='Cell'>

`private` `Cell` — `struct`

<div class='doc' id='1'>

    struct Cell

A custom node type for CommonMark.jl that holds an executable “cell” of code.

</div>

</div>
