# Example Jupyter Notebooks

This page has been written as a Jupyter Notebook, which was introduced in the [Jupyter Notebooks](..\docs\sources.md#jupyter-notebooks) section of the manual. The notebooks provided in this package are just illustrative of how you can integrate notebooks into the rest of your project and still allow for cross references between different parts of the finished document.

Let’s load the required packages. We’re using `Revise` as well since `Publish` integrates well with it and allows you to update your package `src/` contents, such as docstrings, and have the changes reflected in the document output immediately if you’re using the [`serve`](..\docstrings\Publish.serve.md) function.

~~~~~~~~~~julia
using Revise, Publish
~~~~~~~~~~

You can use [`html`](..\docstrings\Publish.html.md) to do a one time build of the project:

~~~~~~~~~~julia
html(Publish)
~~~~~~~~~~

PDFs can be built using [`pdf`](..\docstrings\Publish.pdf.md) in a similar way to [`html`](..\docstrings\Publish.html.md) above:

~~~~~~~~~~julia
pdf(Publish)
~~~~~~~~~~

You probably want to use [`serve`](..\docstrings\Publish.serve.md) instead though, since that’ll spin up a web-server to host your project locally and allow you to view changes in real-time.

~~~~~~~~~~julia
serve(Publish, html, pdf)
~~~~~~~~~~

## Deploying Projects

We usually don’t build our projects in isolation and want others to be able to view our results. For this you can use [`deploy`](..\docstrings\Publish.deploy.md). This function will build your project in the provided directory in a versioned subdirectory.

~~~~~~~~~~julia
deploy(Publish, "build")
~~~~~~~~~~
