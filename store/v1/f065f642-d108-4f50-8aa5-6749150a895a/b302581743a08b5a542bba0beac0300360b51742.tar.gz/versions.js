var PUBLISH_ROOT = 'C:\Users\david\AppData\Local\Temp\jl_n5bwPN\output\0.8.0';
var PUBLISH_VERSION = "0.8.0";
var PUBLISH_VERSIONS = [
    ["0.8.0","C:\\Users\\david\\AppData\\Local\\Temp\\jl_n5bwPN\\output\\0.8.0\\index.html"],
];
